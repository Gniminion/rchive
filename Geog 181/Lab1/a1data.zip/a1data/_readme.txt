Data in this folder was acquired from the City of Kitchener website.
March 3, 2017

License agreement: 
Contains information licensed under the Open Government Licence - The Corporation of the City of Kitchener.